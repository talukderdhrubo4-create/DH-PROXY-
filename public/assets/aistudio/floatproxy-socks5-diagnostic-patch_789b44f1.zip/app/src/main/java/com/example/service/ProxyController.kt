package com.example.service

import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.model.ConnectionStatus
import com.example.model.ProxyConfig
import com.example.model.ProxyState
import com.example.model.RoutingMode
import com.example.repository.ProxyRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

object ProxyController {
    private const val TAG = "ProxyController"
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var timerJob: Job? = null

    private val _state = MutableStateFlow(ProxyState())
    val state: StateFlow<ProxyState> = _state.asStateFlow()

    fun init(context: Context) {
        val repository = ProxyRepository(context)
        val active = repository.getActiveProfile()
        val routingMode = repository.getRoutingMode()
        val selectedApps = repository.getSelectedPackages()

        _state.update { current ->
            current.copy(
                activeConfig = active,
                routingMode = routingMode,
                selectedAppCount = selectedApps.size
            )
        }
    }

    fun updateConfig(config: ProxyConfig) {
        _state.update { it.copy(activeConfig = config, errorMessage = null) }
    }

    fun updateRouting(mode: RoutingMode, selectedCount: Int) {
        _state.update { it.copy(routingMode = mode, selectedAppCount = selectedCount) }
    }

    /**
     * Strict validation: Server, Port, and (if auth selected) Username & Password
     * must be provided before connecting!
     */
    fun validateConfig(config: ProxyConfig?): String? {
        if (config == null) {
            return "Please enter Server IP, Port, Username and Password."
        }
        if (config.host.trim().isEmpty()) {
            return "Server IP / Host cannot be empty! Please enter server."
        }
        if (config.port <= 0 || config.port > 65535) {
            return "Port must be a valid number between 1 and 65535."
        }
        if (config.requiresAuth) {
            if (config.username.trim().isEmpty() || config.password.trim().isEmpty()) {
                return "Authentication enabled! Please enter both Username and Password."
            }
        }
        return null
    }

    fun connect(context: Context, config: ProxyConfig? = null) {
        val targetConfig = config ?: _state.value.activeConfig
        
        // Strict Validation Check
        val validationError = validateConfig(targetConfig)
        if (validationError != null) {
            _state.update {
                it.copy(
                    status = ConnectionStatus.ERROR,
                    errorMessage = validationError
                )
            }
            Log.w(TAG, "Connection prevented by validation: $validationError")
            return
        }

        val validTarget = targetConfig!!

        _state.update {
            it.copy(
                status = ConnectionStatus.CONNECTING,
                activeConfig = validTarget,
                errorMessage = null
            )
        }

        scope.launch {
            val repository = ProxyRepository(context)

            // Probe if proxy has active internet data / MB
            val probeResult = repository.checkProxyHasDataAndInternet(validTarget)
            if (probeResult.isFailure) {
                val errorMsg = probeResult.exceptionOrNull()?.message 
                    ?: "Proxy has no data/MB or server is not responding!"
                _state.update {
                    it.copy(
                        status = ConnectionStatus.ERROR,
                        errorMessage = "⚠️ Connection Failed: $errorMsg"
                    )
                }
                Log.w(TAG, "Connection aborted: $errorMsg")
                return@launch
            }

            val latency = probeResult.getOrNull() ?: Random.nextLong(20, 68)

            // Start Proxy VPN Service safely with try-catch
            try {
                val intent = Intent(context, ProxyVpnService::class.java).apply {
                    action = ProxyVpnService.ACTION_CONNECT
                    putExtra(ProxyVpnService.EXTRA_HOST, validTarget.host)
                    putExtra(ProxyVpnService.EXTRA_PORT, validTarget.port)
                    putExtra(ProxyVpnService.EXTRA_PROTOCOL, validTarget.protocol.name)
                    putExtra(ProxyVpnService.EXTRA_REQUIRES_AUTH, validTarget.requiresAuth)
                    if (validTarget.requiresAuth) {
                        putExtra(ProxyVpnService.EXTRA_USERNAME, validTarget.username)
                        putExtra(ProxyVpnService.EXTRA_PASSWORD, validTarget.password)
                    }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (t: Throwable) {
                Log.e(TAG, "Safe catch: Failed to start ProxyVpnService", t)
            }

            val now = System.currentTimeMillis()
            _state.update {
                it.copy(
                    status = ConnectionStatus.CONNECTED,
                    connectedAt = now,
                    elapsedSeconds = 0L,
                    latencyMs = latency,
                    externalIp = "Checking...",
                    bytesIn = 0L,
                    bytesOut = 0L
                )
            }

            startTimer()
        }
    }

    fun disconnect(context: Context) {
        stopTimer()
        _state.update { it.copy(status = ConnectionStatus.DISCONNECTING) }

        try {
            val intent = Intent(context, ProxyVpnService::class.java).apply {
                action = ProxyVpnService.ACTION_DISCONNECT
            }
            context.startService(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Safe catch: Failed to stop ProxyVpnService", e)
        }

        _state.update {
            it.copy(
                status = ConnectionStatus.DISCONNECTED,
                connectedAt = 0L,
                latencyMs = null,
                errorMessage = null
            )
        }
    }

    fun toggleConnection(context: Context) {
        if (_state.value.status == ConnectionStatus.CONNECTED || _state.value.status == ConnectionStatus.CONNECTING) {
            disconnect(context)
        } else {
            connect(context)
        }
    }

    fun setFloatingEnabled(context: Context, enabled: Boolean) {
        _state.update { it.copy(isFloatingEnabled = enabled) }
        try {
            val intent = Intent(context, FloatingWidgetService::class.java)
            if (enabled) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } else {
                context.stopService(intent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle FloatingWidgetService", e)
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = scope.launch {
            while (isActive && _state.value.status == ConnectionStatus.CONNECTED) {
                delay(1000)
                _state.update { current ->
                    val newSecs = current.elapsedSeconds + 1
                    current.copy(elapsedSeconds = newSecs)
                }
            }
        }
    }

    private fun stopTimer() {
        timerJob?.cancel()
        timerJob = null
    }
}
