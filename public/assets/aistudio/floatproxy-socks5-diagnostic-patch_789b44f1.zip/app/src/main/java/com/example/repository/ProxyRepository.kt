package com.example.repository

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.example.model.AppItem
import com.example.model.ProxyConfig
import com.example.model.ProxyProtocol
import com.example.model.RoutingMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket

class ProxyRepository(private val context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("proxy_float_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PROFILES = "saved_proxy_profiles"
        private const val KEY_ACTIVE_ID = "active_profile_id"
        private const val KEY_ROUTING_MODE = "routing_mode"
        private const val KEY_SELECTED_PACKAGES = "selected_packages"
        private const val KEY_FLOATING_AUTO_MINIMIZE = "floating_auto_minimize"
    }

    init {
        ensureDefaultProfiles()
    }

    private fun ensureDefaultProfiles() {
        if (!prefs.contains(KEY_PROFILES)) {
            val defaults = listOf(
                ProxyConfig(
                    id = "default_socks5",
                    name = "Fast SOCKS5 (Default)",
                    host = "127.0.0.1",
                    port = 1080,
                    protocol = ProxyProtocol.SOCKS5,
                    requiresAuth = false,
                    isDefault = true
                ),
                ProxyConfig(
                    id = "default_http",
                    name = "HTTP Web Proxy",
                    host = "192.168.1.1",
                    port = 8080,
                    protocol = ProxyProtocol.HTTP,
                    requiresAuth = true,
                    username = "user",
                    password = "password"
                ),
                ProxyConfig(
                    id = "default_socks4",
                    name = "Secure SOCKS4 Tunnel",
                    host = "10.0.0.1",
                    port = 1080,
                    protocol = ProxyProtocol.SOCKS4,
                    requiresAuth = false
                )
            )
            saveProfiles(defaults)
            prefs.edit().putString(KEY_ACTIVE_ID, "default_socks5").apply()
        }
    }

    fun getProfiles(): List<ProxyConfig> {
        val jsonString = prefs.getString(KEY_PROFILES, null) ?: return emptyList()
        val list = mutableListOf<ProxyConfig>()
        try {
            val array = JSONArray(jsonString)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    ProxyConfig(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        host = obj.getString("host"),
                        port = obj.getInt("port"),
                        protocol = ProxyProtocol.valueOf(obj.optString("protocol", "SOCKS5")),
                        requiresAuth = obj.optBoolean("requiresAuth", false),
                        username = obj.optString("username", ""),
                        dnsResolution = try {
                            com.example.model.DnsResolution.valueOf(obj.optString("dnsResolution", "PROXY"))
                        } catch (e: Exception) {
                            com.example.model.DnsResolution.PROXY
                        },
                        bypassList = obj.optString("bypassList", "127.0.0.1, localhost"),
                        isDefault = obj.optBoolean("isDefault", false),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun saveProfiles(profiles: List<ProxyConfig>) {
        val array = JSONArray()
        for (item in profiles) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("name", item.name)
            obj.put("host", item.host)
            obj.put("port", item.port)
            obj.put("protocol", item.protocol.name)
            obj.put("requiresAuth", item.requiresAuth)
            obj.put("username", item.username)
            obj.put("password", item.password)
            obj.put("dnsResolution", item.dnsResolution.name)
            obj.put("bypassList", item.bypassList)
            obj.put("isDefault", item.isDefault)
            obj.put("createdAt", item.createdAt)
            array.put(obj)
        }
        prefs.edit().putString(KEY_PROFILES, array.toString()).apply()
    }

    fun addOrUpdateProfile(config: ProxyConfig) {
        val current = getProfiles().toMutableList()
        val index = current.indexOfFirst { it.id == config.id }
        if (index >= 0) {
            current[index] = config
        } else {
            current.add(0, config)
        }
        saveProfiles(current)
    }

    fun deleteProfile(id: String) {
        val current = getProfiles().toMutableList()
        current.removeAll { it.id == id }
        saveProfiles(current)
        if (getActiveProfileId() == id) {
            val first = current.firstOrNull()?.id ?: ""
            setActiveProfileId(first)
        }
    }

    fun getActiveProfileId(): String {
        return prefs.getString(KEY_ACTIVE_ID, "") ?: ""
    }

    fun setActiveProfileId(id: String) {
        prefs.edit().putString(KEY_ACTIVE_ID, id).apply()
    }

    fun getActiveProfile(): ProxyConfig? {
        val id = getActiveProfileId()
        val list = getProfiles()
        return list.firstOrNull { it.id == id } ?: list.firstOrNull()
    }

    fun getRoutingMode(): RoutingMode {
        val modeStr = prefs.getString(KEY_ROUTING_MODE, RoutingMode.ALL_APPS.name)
        return try {
            RoutingMode.valueOf(modeStr ?: RoutingMode.ALL_APPS.name)
        } catch (e: Exception) {
            RoutingMode.ALL_APPS
        }
    }

    fun setRoutingMode(mode: RoutingMode) {
        prefs.edit().putString(KEY_ROUTING_MODE, mode.name).apply()
    }

    fun getSelectedPackages(): Set<String> {
        return prefs.getStringSet(KEY_SELECTED_PACKAGES, emptySet()) ?: emptySet()
    }

    fun setSelectedPackages(packages: Set<String>) {
        prefs.edit().putStringSet(KEY_SELECTED_PACKAGES, packages).apply()
    }

    fun isAutoMinimizeFloating(): Boolean {
        return prefs.getBoolean(KEY_FLOATING_AUTO_MINIMIZE, true)
    }

    fun setAutoMinimizeFloating(value: Boolean) {
        prefs.edit().putBoolean(KEY_FLOATING_AUTO_MINIMIZE, value).apply()
    }

    suspend fun loadInstalledApps(): List<AppItem> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val selected = getSelectedPackages()
        val apps = mutableListOf<AppItem>()
        val seenPackages = mutableSetOf<String>()

        try {
            // 1. Query all launcher apps (guarantees Chrome, browsers, games, etc. are found)
            val launcherIntent = android.content.Intent(android.content.Intent.ACTION_MAIN, null).apply {
                addCategory(android.content.Intent.CATEGORY_LAUNCHER)
            }
            val launcherApps = pm.queryIntentActivities(launcherIntent, 0)
            for (resolveInfo in launcherApps) {
                val pkgName = resolveInfo.activityInfo.packageName
                if (pkgName == context.packageName || seenPackages.contains(pkgName)) continue
                seenPackages.add(pkgName)

                val appName = resolveInfo.loadLabel(pm).toString()
                val icon = try {
                    resolveInfo.loadIcon(pm)
                } catch (e: Exception) {
                    null
                }

                apps.add(
                    AppItem(
                        packageName = pkgName,
                        appName = appName,
                        icon = icon,
                        isSystemApp = false, // User-facing app (like Chrome)
                        isSelected = selected.contains(pkgName)
                    )
                )
            }

            // 2. Query all other installed packages
            val packages = pm.getInstalledPackages(PackageManager.GET_META_DATA)
            for (pkg in packages) {
                val pkgName = pkg.packageName
                if (pkgName == context.packageName || seenPackages.contains(pkgName)) continue
                seenPackages.add(pkgName)

                val hasLaunchIntent = pm.getLaunchIntentForPackage(pkgName) != null
                val isSystem = (pkg.applicationInfo?.flags ?: 0) and ApplicationInfo.FLAG_SYSTEM != 0
                val appName = pkg.applicationInfo?.loadLabel(pm)?.toString() ?: pkgName
                val icon = try {
                    pkg.applicationInfo?.loadIcon(pm)
                } catch (e: Exception) {
                    null
                }

                apps.add(
                    AppItem(
                        packageName = pkgName,
                        appName = appName,
                        icon = icon,
                        isSystemApp = isSystem && !hasLaunchIntent,
                        isSelected = selected.contains(pkgName)
                    )
                )
            }

            // Sort: Selected first, then non-system user apps, then alphabetically
            apps.sortWith(
                compareByDescending<AppItem> { it.isSelected }
                    .thenBy { it.isSystemApp }
                    .thenBy { it.appName.lowercase() }
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
        apps
    }

    suspend fun testProxyPing(host: String, port: Int): Result<Long> = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 2500)
                val latency = System.currentTimeMillis() - startTime
                Result.success(latency)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Checks if the proxy has working data / MB and is responsive to live network requests.
     * Fails if host/port is dead or has no internet balance.
     */
    suspend fun checkProxyHasDataAndInternet(config: ProxyConfig): Result<Long> = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        try {
            Socket().use { socket ->
                socket.soTimeout = 3500
                socket.connect(InetSocketAddress(config.host, config.port), 3500)

                val output = socket.getOutputStream()
                val input = socket.getInputStream()

                when (config.protocol) {
                    ProxyProtocol.SOCKS5 -> {
                        // RFC 1928 greeting: offer no-auth and/or username-password.
                        val methods = if (config.requiresAuth) byteArrayOf(0x00, 0x02) else byteArrayOf(0x00)
                        output.write(byteArrayOf(0x05, methods.size.toByte()) + methods)
                        output.flush()

                        val greeting = ByteArray(2)
                        readFully(input, greeting)
                        if (greeting[0] != 0x05.toByte()) {
                            return@withContext Result.failure(Exception("Invalid SOCKS5 greeting from proxy."))
                        }
                        when (greeting[1].toInt() and 0xff) {
                            0x00 -> Unit // no authentication selected
                            0x02 -> {
                                if (!config.requiresAuth) {
                                    return@withContext Result.failure(Exception("Proxy requires username/password. Enable authentication in the profile."))
                                }
                                val user = config.username.toByteArray(Charsets.UTF_8)
                                val pass = config.password.toByteArray(Charsets.UTF_8)
                                if (user.isEmpty() || pass.isEmpty() || user.size > 255 || pass.size > 255) {
                                    return@withContext Result.failure(Exception("SOCKS5 username/password must each be 1–255 bytes."))
                                }
                                output.write(byteArrayOf(0x01, user.size.toByte()) + user + byteArrayOf(pass.size.toByte()) + pass)
                                output.flush()
                                val authReply = ByteArray(2)
                                readFully(input, authReply)
                                if (authReply[1] != 0x00.toByte()) {
                                    return@withContext Result.failure(Exception("SOCKS5 authentication failed. Check username/password."))
                                }
                            }
                            0xff -> return@withContext Result.failure(Exception("SOCKS5 server supports none of the offered authentication methods."))
                            else -> return@withContext Result.failure(Exception("SOCKS5 server selected an unsupported authentication method."))
                        }

                        // Verify that the proxy can open a remote TCP connection, not just accept a socket.
                        val host = "connectivitycheck.gstatic.com".toByteArray(Charsets.US_ASCII)
                        output.write(byteArrayOf(0x05, 0x01, 0x00, 0x03, host.size.toByte()) + host + byteArrayOf(0x01, 0xbb.toByte()))
                        output.flush()
                        val reply = ByteArray(4)
                        readFully(input, reply)
                        if (reply[0] != 0x05.toByte() || reply[1] != 0x00.toByte()) {
                            return@withContext Result.failure(Exception("SOCKS5 authentication succeeded, but remote connection failed (reply ${reply[1].toInt() and 0xff})."))
                        }
                        val addressLength = when (reply[3].toInt() and 0xff) {
                            0x01 -> 4
                            0x04 -> 16
                            0x03 -> {
                                val length = input.read()
                                if (length < 0) return@withContext Result.failure(Exception("Incomplete SOCKS5 response."))
                                length
                            }
                            else -> return@withContext Result.failure(Exception("Invalid SOCKS5 response address type."))
                        }
                        readFully(input, ByteArray(addressLength + 2)) // bound address + port
                    }
                    ProxyProtocol.HTTP, ProxyProtocol.HTTPS -> {
                        val authHeader = if (config.requiresAuth && config.username.isNotBlank()) {
                            val creds = "${config.username}:${config.password}"
                            val encoded = android.util.Base64.encodeToString(creds.toByteArray(), android.util.Base64.NO_WRAP)
                            "Proxy-Authorization: Basic $encoded\r\n"
                        } else ""

                        val probe = "GET http://connectivitycheck.gstatic.com/generate_204 HTTP/1.1\r\n" +
                                "Host: connectivitycheck.gstatic.com\r\n" +
                                authHeader +
                                "Connection: close\r\n\r\n"
                        output.write(probe.toByteArray())
                        output.flush()

                        val buffer = ByteArray(512)
                        val read = input.read(buffer)
                        if (read <= 0) {
                            return@withContext Result.failure(Exception("Proxy server has no active internet data (0 MB)."))
                        }
                        val header = String(buffer, 0, read)
                        if (header.contains("407 Proxy Authentication Required")) {
                            return@withContext Result.failure(Exception("Proxy Authentication Failed! Check username/password."))
                        }
                    }
                    ProxyProtocol.SOCKS4 -> {
                        output.write(byteArrayOf(0x04, 0x01, 0x00, 0x50, 0x08, 0x08, 0x08, 0x08, 0x00))
                        output.flush()
                    }
                }

                val latency = System.currentTimeMillis() - startTime
                Result.success(latency)
            }
        } catch (e: Exception) {
            Result.failure(Exception("Proxy has no internet data/MB or cannot be reached: ${e.localizedMessage ?: "Timeout"}"))
        }
    }

    private fun readFully(input: java.io.InputStream, target: ByteArray) {
        var offset = 0
        while (offset < target.size) {
            val count = input.read(target, offset, target.size - offset)
            if (count < 0) throw java.io.EOFException("Proxy closed connection during SOCKS5 handshake")
            offset += count
        }
    }

}
