package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.model.RoutingMode
import com.example.repository.ProxyRepository

class ProxyVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null

    companion object {
        const val ACTION_CONNECT = "com.example.proxyfloat.ACTION_CONNECT"
        const val ACTION_DISCONNECT = "com.example.proxyfloat.ACTION_DISCONNECT"
        const val EXTRA_HOST = "extra_host"
        const val EXTRA_PORT = "extra_port"
        const val EXTRA_PROTOCOL = "extra_protocol"
        const val EXTRA_USERNAME = "extra_username"
        const val EXTRA_PASSWORD = "extra_password"
        const val EXTRA_REQUIRES_AUTH = "extra_requires_auth"

        private const val NOTIFICATION_ID = 2001
        private const val CHANNEL_ID = "proxy_vpn_channel"
        private const val TAG = "ProxyVpnService"
    }

    override fun onCreate() {
        super.onCreate()
        try {
            createNotificationChannel()
            // Immediately start foreground in onCreate to guarantee Android 14 compliance
            val notification = createNotification("DH PROXY Engine Active")
            startForeground(NOTIFICATION_ID, notification)
        } catch (t: Throwable) {
            Log.e(TAG, "Error in onCreate startForeground", t)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            when (intent?.action) {
                ACTION_CONNECT -> {
                    val host = intent.getStringExtra(EXTRA_HOST) ?: "127.0.0.1"
                    val port = intent.getIntExtra(EXTRA_PORT, 1080)
                    val protocol = intent.getStringExtra(EXTRA_PROTOCOL) ?: "SOCKS5"
                    startVpn(host, port, protocol)
                }
                ACTION_DISCONNECT -> {
                    stopVpn()
                }
                else -> {
                    val host = intent?.getStringExtra(EXTRA_HOST) ?: "127.0.0.1"
                    val port = intent?.getIntExtra(EXTRA_PORT, 1080) ?: 1080
                    val protocol = intent?.getStringExtra(EXTRA_PROTOCOL) ?: "SOCKS5"
                    startVpn(host, port, protocol)
                }
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Error handling start command", t)
        }
        return START_NOT_STICKY
    }

    private fun startVpn(host: String, port: Int, protocol: String) {
        try {
            val notification = createNotification("DH PROXY Connected: $protocol://$host:$port")
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.notify(NOTIFICATION_ID, notification)

            try {
                vpnInterface?.close()
                vpnInterface = null
            } catch (e: Exception) {
                Log.e(TAG, "Error closing previous vpn interface", e)
            }

            // Check if VPN is prepared
            val prepareIntent = prepare(this)
            if (prepareIntent != null) {
                Log.w(TAG, "VPN service not prepared by user yet, opening MainActivity")
                val activityIntent = Intent(this, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("REQUEST_VPN_CONSENT", true)
                }
                startActivity(activityIntent)
                return
            }

            val builder = Builder()
                .setSession("DH PROXY - $protocol")
                .setMtu(1500)
                .addAddress("10.0.0.2", 24)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("8.8.8.8")
                .addDnsServer("1.1.1.1")

            val repository = ProxyRepository(this)
            val mode = repository.getRoutingMode()
            val selectedPackages = repository.getSelectedPackages()

            when (mode) {
                RoutingMode.SELECTED_ONLY -> {
                    for (pkg in selectedPackages) {
                        try {
                            builder.addAllowedApplication(pkg)
                        } catch (e: Exception) {
                            Log.w(TAG, "Package $pkg not found for allowed application")
                        }
                    }
                }
                RoutingMode.BYPASS_SELECTED -> {
                    for (pkg in selectedPackages) {
                        try {
                            builder.addDisallowedApplication(pkg)
                        } catch (e: Exception) {
                            Log.w(TAG, "Package $pkg not found for disallowed application")
                        }
                    }
                }
                RoutingMode.ALL_APPS -> {
                    // Global tunneling
                }
            }

            vpnInterface = builder.establish()
            Log.i(TAG, "VPN interface established successfully")
        } catch (se: SecurityException) {
            Log.e(TAG, "SecurityException: VPN consent required", se)
            val activityIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("REQUEST_VPN_CONSENT", true)
            }
            try {
                startActivity(activityIntent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to establish VPN interface", t)
        }
    }

    private fun stopVpn() {
        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        stopSelf()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "DH PROXY Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows active proxy status and duration"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(contentText: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("DH PROXY Active")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .build()
    }
}
