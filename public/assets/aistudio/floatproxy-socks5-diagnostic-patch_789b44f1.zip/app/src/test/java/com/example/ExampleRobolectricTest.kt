package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.ConnectionStatus
import com.example.model.ProxyConfig
import com.example.model.ProxyProtocol
import com.example.model.ProxyState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("DH PROXY", appName)
  }

  @Test
  fun `test proxy config and timer formatted`() {
    val config = ProxyConfig(
      name = "Test SOCKS5",
      host = "127.0.0.1",
      port = 1080,
      protocol = ProxyProtocol.SOCKS5
    )
    assertEquals("Test SOCKS5", config.name)
    assertEquals(1080, config.port)

    val state = ProxyState(
      status = ConnectionStatus.CONNECTED,
      activeConfig = config,
      elapsedSeconds = 3665 // 1h 1m 5s
    )
    assertEquals("01:01:05", state.formattedTime())
  }
}
